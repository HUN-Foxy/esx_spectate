# esx_spectate

Advanced version of ES_CAMERA
